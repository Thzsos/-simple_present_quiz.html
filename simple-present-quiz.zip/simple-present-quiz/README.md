# Simple Present Quiz

Este projeto é um quiz interativo de inglês focado no tempo verbal *Simple Present*.

## Como usar

Abra o arquivo `simple_present_quiz.html` em qualquer navegador moderno para testar seus conhecimentos.

## Publicação

Você pode publicar este projeto no GitHub Pages seguindo estes passos:

1. Faça o upload deste repositório para o GitHub.
2. Vá até a aba "Settings" do repositório.
3. Na seção "Pages", escolha a branch `main` e a pasta `/ (root)`.
4. Clique em "Save" e acesse o link gerado para visualizar o site.

Desenvolvido com HTML, CSS e JavaScript.
